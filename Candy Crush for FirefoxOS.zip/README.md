Candy-Crush-for-Firefox-OS
==========================

Candy CRush Gameplay for Firefox OS
